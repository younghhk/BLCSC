#' this funciton is used to standardize covariate and it need not export.
#'
#' @param cor_mat
#' @param thres
#' @keywords
#' @examples
#'


max_connected_graph = function(cor_mat,thres){
  tmp = (abs(cor_mat)>thres)
  tmp = which(tmp, arr.ind=TRUE)
  edge_index_pair = tmp[tmp[,2]>tmp[,1],]
  edge = as.vector(t(edge_index_pair))
  gph = graph(edge, n=as.numeric(dim(cor_mat)[1]), directed=FALSE)
  max_connect = clusters(gph)$membership
  return(max_connect)
}
