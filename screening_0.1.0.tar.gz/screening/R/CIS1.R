#' This function is do the sp selcetion with the bootstrap part. It returns the FDR_delta.
#' @param delta
#' @param block_ID
#' @param maxit defalut value = 3
#' @param d2 defalut value = floor(0.1*N/log(N))
#' @param stable_all defalut value=20 number of bootstrap
#' @param permute_all defalut value=10 number of permutation
#' @param delta default vaule=delta=4*(log(p)/N)**0.5
#' @import mvtnorm
#' @import survival
#' @import Matrix
#' @import glmnet
#' @import igraph
#' @import ppcor
#' @import corpcor
#' @import parcor
#' @keywords
#' @export
#' @examples

CIS1<-function(Y=Y, z=z,stable_all=20,permute_all=10,delta=FALSE) {

  N=length(Y)
  p=ncol(z)
  if(delta==FALSE){
    delta=4*(log(p)/N)**0.5
  }

  summary_ICIS=NULL
  freq_ICIS=NULL
  freq_ICIS_permute=NULL
  ICIS_time=NULL
  ICIS_stable_time=NULL

  time=proc.time()
  cov=cor(z)
  block_ID=max_connected_graph(cor_mat=cov,thres=delta)
  j_unique=length(unique(block_ID))

  #############################CIS with PC
  number.groups=length(unique(block_ID))
  cov_y=cov(Y)

  I_CIS_SPC_out=I_CIS_SPC(Y, z, block_ID, 3,floor(0.1*N/log(N))) ## here the maxit and d2 should ????

  beta_SPC=I_CIS_SPC_out$beta_SPC

  time=proc.time()-time
  ICIS_time=c(ICIS_time, time[3])

  #I_CIS_SPC_out$SPC_track

  time=proc.time()
  select_ICIS=NULL

  stable=0
  while (stable<stable_all){
    stable=stable+1

    index_boot=sample(1:N, size=floor(N/2), replace=FALSE)
    N2=length(index_boot)
    N1=N-N2

    z1=z[-index_boot,]


    Y1=Y[-index_boot]
    #Y1=Y1-mean(Y1)

    z2=z[index_boot,]

    Y2=Y[index_boot]
    #Y2=Y2-mean(Y2)
    Y2<-matrix(Y2,nrow = length(Y2),ncol = 1) ####added by me

    ##########################CIS

    I_CIS_SPC_out=I_CIS_SPC(Y=Y2, z=z2, block_ID=block_ID, maxit=3, d2=floor(0.1*N2/log(N2)))

    beta_SPC=I_CIS_SPC_out$beta_SPC

    select_ICIS=rbind(select_ICIS, (beta_SPC!=0))

  } #end stable

  freq_ICIS=rbind(freq_ICIS, colMeans(select_ICIS))





  permute=0
  while ( permute< permute_all){
    permute= permute+1

    permute_index=sample(1:N)
    Y_permute=Y[permute_index]

    select_ICIS_permute=NULL
    stable=0
    while (stable<stable_all){
      stable=stable+1

      index_boot=sample(1:N, size=floor(N/2), replace=FALSE)
      N2=length(index_boot)
      N1=N-N2

      z1=z[-index_boot,]


      Y1=Y_permute[-index_boot]
      #Y1=Y1-mean(Y1)

      z2=z[index_boot,]

      Y2=Y_permute[index_boot]
      Y2<-matrix(Y2,nrow = length(Y2),ncol = 1)  ######## added by me


      ##########################CIS


      I_CIS_SPC_out=I_CIS_SPC(Y=Y2, z=z2, block_ID=block_ID, maxit=3, d2=floor(0.25*N2/log(N2)))

      beta_SPC=I_CIS_SPC_out$beta_SPC

      select_ICIS_permute=rbind(select_ICIS_permute, (beta_SPC!=0))


    } #end stable
    freq_ICIS_permute=rbind(freq_ICIS_permute, colMeans(select_ICIS_permute))

  } #end permute

  time=proc.time()-time
  ICIS_stable_time=c(ICIS_stable_time, time[3])

  ##############summary
  rev_order=function(x){
    x[rev(order(x))]
  }
  key=0
  B=permute_all
  for (i in 1:nrow(freq_ICIS)) {
    temp=freq_ICIS[i,]
    order=temp[rev(order(temp))]

    temp2=freq_ICIS_permute[(key+1):(key+B),]
    order_permute=t(apply(temp2, 1, rev_order))

    mean_order_permute=colMeans(order_permute)
    diff=order-mean_order_permute

    Delta=max(diff)*(1:B)/(B+1)

    FDR_Delta=NULL
    C_Delta_all=NULL
    for (k in 1:B) {
      C_Delta=order[which(diff>=Delta[k])[sum((diff>=Delta[k]))]]
      C_Delta_all=c(C_Delta_all,C_Delta)
      R_Delta=sum(freq_ICIS[i,]>=as.numeric(C_Delta))
      R_Delta_permute=sum(order_permute>=as.numeric(C_Delta))
      FDR_Delta=c(FDR_Delta, R_Delta_permute/(R_Delta*B))
    }
  }

  cat("C_Delta:",C_Delta,"\n")
  cat("C_Delta_all:",C_Delta_all,"\n")
  cat("R_Delta:",R_Delta,"\n")
  cat("R_Delta_permute:",R_Delta_permute,"\n")
  cat("FDR_Delta:",FDR_Delta,"\n")
  return(FDR_Delta)

}
