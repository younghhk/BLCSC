#' This function is used to iterative CIS and need not export
#' @param Y
#' @param z
#' @param block_ID block index
#' @param maxit the maxiumum iteration number
#' @param d2 number of variables returned in the screening step
#' @keywords
#' @examples
#'

I_CIS_SPC <- function(Y=Y, z=z, block_ID=block_ID, maxit=maxit,d2=d2) {

  N=length(Y)
  p=ncol(z)
  cov_y=cov(Y) #######added by me
  active_SPC=NULL
  SPC_track=NULL
  #PC_track2=NULL
  beta_SPC=rep(0,p)
  size_SPC=0
  j_unique=length(unique(block_ID))
  number.groups=length(unique(block_ID))

  key=0
  repeat{
    key=key+1
    Y_SPC=Y-z%*%beta_SPC

    active_SPC2=active_SPC
    size_SPC=length(active_SPC)
    beta_SPC2=rep(0,p)
    group=0
    while (group<number.groups){
      group= group+1
      p_temp=sum(block_ID==group)
      index_temp=which(block_ID==group)
      yz_temp=cbind(Y_SPC, z[,index_temp])

      aa2<-pcor.shrink(yz_temp)
      aa3<-pvar.shrink(yz_temp)

      aa<-aa2[1,-1]
      beta_SPC2[block_ID==group]=aa/(cov_y*sqrt((1-aa*aa2[-1,1])/aa3[1]))
    }


    active_SPC=unique(c(active_SPC,order(abs(beta_SPC2), decreasing=TRUE)[1:d2]))


    SPC_track[[key]]=active_SPC

    size_SPC=sum(beta_SPC!=0)


    z_temp=z[,active_SPC]

    if (length(active_SPC)==1) {
      beta_SPC=rep(0,p)
      beta_SPC[active_SPC]=solve(t(z_temp)%*%z_temp)%*%t(z_temp)%*%Y
    }
    if (length(active_SPC)==0) {
      beta_SPC=rep(0,p)
    }

    if (length(active_SPC)>1) {

      ada.object<-adalasso(z_temp,Y,k=3)
      beta_SPC=rep(0,p)
      beta_SPC[active_SPC]=ada.object$coefficients.adalasso
      #ada.object$coefficients.lasso
    }
    active_SPC=which(beta_SPC!=0)


    #PC_track2[[key]]=active_PC

    size_SPC=sum(beta_SPC!=0)


    if (identical(active_SPC, active_SPC2)==TRUE) break
    #if ((d1- size_PC)==0) break
    if (key==maxit) break
  }
  #list(beta_PC=beta_PC, active_PC=active_PC, size_PC=size_PC, PC_track=PC_track, PC_track2=PC_track2)
  list(beta_SPC=beta_SPC, active_SPC=active_SPC, size_SPC=size_SPC, SPC_track=SPC_track)

}
