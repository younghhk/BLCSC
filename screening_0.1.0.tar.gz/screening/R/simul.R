#' This function is used to generate Y for simulation
#'
#' With default values, this may take 20 minutes.
#' @param n
#' @param p
#' @param m1
#' @param sp the defalut value is TRUE. When it's false, the function returns the beta_SPC without the bootstrap. it called the function CIS2. And when it's true, it called the function CIS1, returning the FDR_Delta
#' @keywords
#' @export
#' @import mvtnorm
#' @import survival
#' @import Matrix
#' @import glmnet
#' @import igraph
#' @import ppcor
#' @import corpcor
#' @import parcor
#' @examples simul(N=500,p=1000,mag=1,sp=TRUE)
#'

simuly <- function(N=500,p=1000,sp=TRUE) {

  m1=floor(p/10)
  mag=1

  AR1 <- function(tau, m) {
    if(m==1) {R <- 1}
    if(m > 1) {
      R <- diag(1, m)
      for(i in 1:(m-1)) {
        for(j in (i+1):m) {
          R[i,j] <- R[j,i] <- tau^(abs(i-j))
        }
      }
    }
    return(R)
  }
  normalize = function(x){
    y = sqrt(length(x))*(x-mean(x))/sqrt(sum((x-mean(x))^2))
    return(y)
  }

  Sigma_z1=diag(p)

  Corr1<-AR1(0.9,m1)

  diag(Corr1) <- 1

  z=NULL
  j=0
  while(j<(p/m1)){
    j=j+1
    z=cbind(z,rmvnorm(N, mean=rep(0,m1), sigma=Corr1))
  }

  z=apply(z,2,normalize)

  TrueBeta <- rep(0, p)
  TrueBeta[1] =mag
  TrueBeta[2] = -mag
  TrueBeta[m1+1] <- mag
  TrueBeta[m1+2] <- -mag
  TrueBeta[2*m1+1] <- -1
  TrueBeta[3*m1+1] <- 1
  TrueBeta[4*m1+1] <- -1
  TrueBeta[5*m1+1] <- 1
  TrueBeta[6*m1+1] <- -1
  TrueBeta[7*m1+1] <- 1
  signbeta=sign(TrueBeta)

  Y<-z%*%TrueBeta+ rnorm(N)
  output<-list(Y,z)
  return(output)
}
