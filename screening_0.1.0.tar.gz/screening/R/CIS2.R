#' This function is do the sp selcetion without the bootstrap part. It returns the beta_spc.
#' @param delta
#' @param block_ID
#' @param maxit defalut value = 3
#' @param delta default vaule=delta=4*(log(p)/N)**0.5
#' @import mvtnorm
#' @import survival
#' @import Matrix
#' @import glmnet
#' @import igraph
#' @import ppcor
#' @import corpcor
#' @import parcor
#' @keywords
#' @export
#' @examples

CIS2<-function(Y=Y, z=z,delta=FALSE,maxit=3) {

  N=length(Y)
  p=ncol(z)
  if(delta==FALSE){
    delta=4*(log(p)/N)**0.5
  }

  summary_ICIS=NULL
  freq_ICIS=NULL
  freq_ICIS_permute=NULL
  ICIS_time=NULL
  ICIS_stable_time=NULL

  time=proc.time()
  cov=cor(z)
  block_ID=max_connected_graph(cor_mat=cov,thres=delta)
  j_unique=length(unique(block_ID))

  #############################CIS with PC
  number.groups=length(unique(block_ID))
  cov_y=cov(Y)

  I_CIS_SPC_out=I_CIS_SPC(Y, z, block_ID, maxit,floor(0.1*N/log(N)))

  beta_SPC=I_CIS_SPC_out$beta_SPC

  time=proc.time()-time
  ICIS_time=c(ICIS_time, time[3])

  #I_CIS_SPC_out$SPC_track

  time=proc.time()

  cat("Beta_SPC:",beta_SPC,"\n")
  return(beta_SPC)


}
